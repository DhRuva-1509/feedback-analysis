def handler(event, context):
    return {
        "statusCode": 200,
        "body": "Analyze Feedback Lambda executed successfully"
    }